<div class="sidebar sidebar-hide-to-small sidebar-shrink sidebar-gestures">
        <div class="nano">
            <div class="nano-content">
                <ul>

                    <li class="label">Main</li>
                    <li><a href="dashboard.php" ><i class="ti-home"></i>Dashboard</a></li>
                   <li><a href="class.php"><i class="ti-files"></i>Class</a>
                    </li>
                     <li><a href="subject.php"><i class="ti-files"></i>Subject</a>
                    </li>
                    
                    <li><a class="sidebar-sub-toggle"><i class="ti-user"></i>  Teacher  <span class="sidebar-collapse-icon ti-angle-down"></span></a>
                        <ul>
                             <li><a href="add-teacher.php">Add Teacher</a>
                    </li>
                            <li><a href="manage-teacher.php">Manage Teacher</a></li>
                           
                        </ul>
                    </li>
                      <li><a href="subjectclass-allocation.php"><i class="ti-files"></i>Subject Allocation</a>
                    </li>
                   
                  <li><a href="class-rooms.php" ><i class="ti-file"></i>Class Rooms</a></li> 
                  <li><a href="time-slots.php" ><i class="ti-file"></i>Time Slots</a></li> 
                   <li><a href="time-table.php" style="color:red;"><strong><i class="ti-file"></i>Time Table</a></strong></li> 
                </ul>
            </div>
        </div>
    </div>      